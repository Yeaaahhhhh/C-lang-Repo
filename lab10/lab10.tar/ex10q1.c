
#include "lab10.h"

struct node;
struct dictionary;

// see "lab10.h" for requirements.
struct dictionary *dict_create(void) {


}

// see "lab10.h" for requirements.
void dict_destroy(struct dictionary **dict) {


	return;
}

// see "lab10.h" for requirements.
void dict_add(struct dictionary *dict, const char *str) {


	return;
}

// see "lab10.h" for requirements.
void dict_remove(struct dictionary *dict, const char *str) {


	return;
}

// see "lab10.h" for requirements.
int dict_search(const struct dictionary *dict, const char *str) {


}

// see "lab10.h" for requirements.
int dict_count(const struct dictionary *dict) {


}

// see "lab10.h" for requirements.
char *dict_get(const struct dictionary *dict, int pos) {


}

// see "lab10.h" for requirements.
void dict_merge(struct dictionary *dict1, struct dictionary **dict2) {


	return;
}

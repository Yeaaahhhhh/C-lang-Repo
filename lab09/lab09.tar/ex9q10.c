
#include "lab09.h"

//the following function generates a shape of `n` points uniformly randomly distributed in the area
//complete the function definition:
// 1) return NULL if the given number `n` is invalid;
// 2) you do not need to free the dynamically allocate memory for the new shape;
struct point *generate(int n) { //requires 1 <= n <= 1000



}

//the following function destroys a given shape pointed to by `head`
//complete the function definition:
// 1) do nothing if the given shape is NULL;
// 2) you need to free the dynamically allocated points in the shape;
void cleanup(struct point *head) {


	return;
}

/* Purpose(s):
 * Author:
 * Date:
 * Persons discussed w/:
 * References:
 */

#include "lab05.h"

int main() {

	testing(15, __LINE__, __FILE__);
	testing(20, __LINE__, __FILE__);
	testing(30, __LINE__, __FILE__);
	testing(50, __LINE__, __FILE__);
	testing(100, __LINE__, __FILE__);

	return 0;
}

//the following function returns the number at position n;
//complete the function definition:
// 1) should be a recursion
int modified_Fibonacci(int n) {


}

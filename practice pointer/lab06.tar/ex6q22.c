
#include "lab06.h"

//the following function implements mergesort algorithm;
//complete the function definition as a recursion:
// 1) to sort an integer array from position `left` to position `right` (inclusive) into the non-decreasing order;
// 2) if an assignment operation involves an array element, you should use keyassign();
// 3) if a comparison operation involves an array element, you should use keycomp();
// 4) should be a recursion:
// 4.1) divide into two sub-arrays of the equal length (off by 1);
// 4.2) recursively sort each;
// 4.3) merge the sorted sub-arrays;
void mergesort(int a[], int left, int right) {




}

//the following function merges a[left .. mid] and a[mid+1 .. right] into a sorted array a[left .. right];
//complete the function definition:
// 1) you can assume a[left .. mid] and a[mid+1 .. right] are sorted separately
void merge(int a[], int left, int mid, int right) {




}

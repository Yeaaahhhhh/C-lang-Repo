
#include "lab06.h"

//the following function implements insertionsort algorithm;
//complete the function definition:
// 1) to sort an array of n integers into the non-decreasing order;
// 2) if an assignment operation involves an array element, you should use keyassign();
// 3) if a comparison operation involves an array element, you should use keycomp();
// 4) should be in-space sorting, i.e.,
// 4.1) shuffle array elements around inside the array;
// 4.2) no extra array can be used for the sorting purpose;
void insertionsort(int a[], int n) {




}

/* Purpose(s):
 * Author:
 * Date:
 * Persons discussed w/:
 * References:
 */

#include "lab06.h"

int main(int argc, char **argv) {
    int a[N];
    int *b = a;
    int *c = b;

    check_foo1(a, N, __LINE__, __FILE__);
    check_foo2(b, N, __LINE__, __FILE__);
    check_foo3(c, N, __LINE__, __FILE__);
    return 0;
}

//the following function sets value n-i to the position i in the sequence of n integers, stored from the address pointed by p;
//complete the function definition:
// 1) you can assume that the entire chunk of memory is owned by your program;
// 2) you cannot use squared parentheses "[]" inside;
void foo1(int *p, int n) {



}

//the following function reverses the sequence of n integers, stored from the address pointed by p;
//complete the function definition:
// 1) you can assume that the entire chunk of memory is owned by your program;
// 2) you cannot use squared parentheses "[]" inside;
void foo2(int *p, int n) {



}

//the following function returns the maximum value among the sequence of n integers, stored from the address pointed by p;
//complete the function definition:
// 1) you can assume that the entire chunk of memory is owned by your program;
// 2) you cannot use squared parentheses "[]" inside;
int foo3(const int *p, int n) {




}


#include "lab08.h"

int main(int argc, char *argv[]) {
	if (argc != 3)
		return 0;
	check_validate(argv[1], __LINE__, __FILE__);
	check_validate(argv[2], __LINE__, __FILE__);
    check_add(argv[1], argv[2], __LINE__, __FILE__);
    check_gt(argv[1], argv[2], __LINE__, __FILE__);
    check_eq(argv[1], argv[2], __LINE__, __FILE__);
    check_diff(argv[1], argv[2], __LINE__, __FILE__);
    check_multiply(argv[1], argv[2], __LINE__, __FILE__);
    check_divide(argv[1], argv[2], __LINE__, __FILE__);
    check_modulo(argv[1], argv[2], __LINE__, __FILE__);
	return 0;
}

//the following function validates whether the string `p` represents a non-negative integer
//complete the function definition:
// 1) `p` is valid (not NULL);
// 2) a valid non-negative integer representation is either "0" or a sequence of digits w/o leading zeros
//    examples: "5678" corresponds to the integer 5678
//           "0" corresponds to the integer 0 (zero)
//           "005678" is invalid
//           "00" is invalid
//           "-1" is invalid
//           "123abc45" is invalid
// 3) return true iff `p` represents a non-negative integer
bool validate(const char *p) {

}

//the following function returns a new string representing m + n
//complete the function definition:
// 1) you can assume both m and n represent non-negative integers
// 2) you do not need to free the dynamically allocate memory for the new string
char *add(const char *m, const char *n) {

}

//the following function validates whether m > n
//complete the function definition:
// 1) you can assume both m and n represent non-negative integers
// 2) return true if m > n
bool gt(const char *m, const char *n) {

}

//the following function validates whether m == n
//complete the function definition:
// 1) you can assume both m and n represent non-negative integers
// 2) return true if m == n
bool eq(const char *m, const char *n) {

}

//the following function returns a new string representing |m - n|
//complete the function definition:
// 1) you can assume both m and n represent non-negative integers
// 2) you do not need to free the dynamically allocate memory for the new string
char *diff(const char *m, const char *n) {

}

//the following function returns a new string representing m * n
//complete the function definition:
// 1) you can assume both m and n represent non-negative integers
// 2) you do not need to free the dynamically allocate memory for the new string
char *multiply(const char *m, const char *n) {

}

//the following function returns a new string representing m / n
//complete the function definition:
// 1) you can assume both m and n represent non-negative integers
// 2) return NULL if n == 0;
// 3) you do not need to free the dynamically allocate memory for the new string
char *divide(const char *m, const char *n) {

}

//the following function returns a new string representing m % n
//complete the function definition:
// 1) you can assume both m and n represent non-negative integers
// 2) return NULL if n == 0;
// 3) you do not need to free the dynamically allocate memory for the new string
char *modulo(const char *m, const char *n) {

}


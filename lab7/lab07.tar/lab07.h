
#include <stdio.h>
#include <assert.h>

#define N 10

size_t any_2_int(parameter1, size_t, parameter3);//you need to decide your function declaration
void check(const void *, size_t, int *, size_t, int, char *);

int min_above_key(int const *, int, int);
void index_order(int const *, int, int *);
void check_order(int const *, int, int *, int, char *);

void coefficient(int, char [], char *);
void check_coefficient(int, char [], char, int, char *);

